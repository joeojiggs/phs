<?php

if($hospital_name == 'AFH'){
    $full_name = '48th Armed Forces Hospital, Lagos.';
}elseif($hospital_name == 'AFH2'){
    $full_name = '68th Armed Forces Hospital, Lagos';
}elseif($hospital_name == 'ASUTH'){
    $full_name = 'Abia State University Teaching Hospital, Aba';
}elseif($hospital_name == 'ATBUTHB'){
    $full_name = 'Abubakar Tafawa Balewa University Teaching Hospital, Bauchi';
}elseif($hospital_name == 'ACA'){
    $full_name = 'Abuja Clinics, Abuja';
}elseif($hospital_name == 'ATBUTHB'){
    $full_name = 'Abubakar Tafawa Balewa University Teaching Hospital, Bauchi';
}elseif($hospital_name == 'ABUTH'){
    $full_name = 'Ahmadu Bello University Teaching Hospital, Zaria';
}elseif($hospital_name == 'ABUTH'){
    $full_name = 'Ahmadu Bello University Teaching Hospital, Zaria';
}elseif($hospital_name == 'AKTH'){
    $full_name = 'Aminu Kano Teaching Hospital, Kano';
}elseif($hospital_name == 'ASUTH'){
    $full_name = 'Anambra State University Teaching Hospital, Amaku Awka';
}elseif($hospital_name == 'AFH'){
    $full_name = 'Armed Forces Hospital';
}elseif($hospital_name == 'ARC'){
    $full_name = 'Aso Rock Clinic';
}elseif($hospital_name == 'BUTH'){
    $full_name = 'Babcock University Teaching Hospital';
}elseif($hospital_name == 'BUTH'){
    $full_name = 'Babcock University Teaching Hospital';
}
elseif($hospital_name == 'BMC'){
    $full_name = 'Baptist Medical Centre, Saki';
}elseif($hospital_name == 'BDSH'){
    $full_name = 'Barau Dikko Specialist Hospital, Kaduna';
}elseif($hospital_name == 'BSUTH'){
    $full_name = 'Benue State University Teaching Hospital Makurdi';
}elseif($hospital_name == 'BUTHJ'){
    $full_name = 'Bingham University Teaching Hospital Jos';
}elseif($hospital_name == 'BMHPH'){
    $full_name = 'Braithewaite Memorial Hospital, Port Harcourt';
}elseif($hospital_name == 'CHBC'){
    $full_name = 'Central Hospital, Benin City';
}elseif($hospital_name == 'DAHL'){
    $full_name = 'Dalhatu Araf Hospital, Lafia';
}elseif($hospital_name == 'DSUTH'){
    $full_name = 'Delta State University Teaching Hospital, Oghara';
}elseif($hospital_name == 'DCCD'){
    $full_name = 'Dental Centre Complex Dugbe, Ibadan';
}elseif($hospital_name == 'DSH'){
    $full_name = 'Duro Soleye Hospital, Ikeja';
}elseif($hospital_name == 'ESUTH'){
    $full_name = 'Ebonyi State University Teaching Hospital, Abakaliki';
}elseif($hospital_name == 'EHP'){
    $full_name = 'Eko Hospital Plc, Ikeja';
}elseif($hospital_name == 'FCMC'){
    $full_name = 'First Consultant medical centre Obalande';
}elseif($hospital_name == 'GHA'){
    $full_name = 'Garki Hospital, Abuja';
}elseif($hospital_name == 'GHO'){
    $full_name = 'General Hospital Onitsha';
}elseif($hospital_name == 'GHI'){
    $full_name = 'General Hospital, Ikot-Ekpene';
}elseif($hospital_name == 'GHM'){
    $full_name = 'General Hospital, Minna';
}elseif($hospital_name == 'GHCH'){
    $full_name = 'General Hospital/Island Maternity/Massey Children’s Hospital, Lagos';
}elseif($hospital_name == 'HSHS'){
    $full_name = 'Havanah Specialist Hospital Ltd, Surulere';
}elseif($hospital_name == 'HRHE'){
    $full_name = 'Holy Rosary Hospital Emekuku';
}elseif($hospital_name == 'IUTH'){
    $full_name = 'Igbinedion University Teaching Hospital, Okada';
}elseif($hospital_name == 'IGH'){
    $full_name = 'Immanuel General Hospital, Eket';
}elseif($hospital_name == 'ISUTHO'){
    $full_name = 'Imo State University Teaching Hospital Orlu, Imo Statet';
}elseif($hospital_name == 'JUTH'){
    $full_name = 'Jos University Teaching Hospital';
}elseif($hospital_name == 'LUSTH'){
    $full_name = 'Lagos State University Teaching Hospital, Ikeja';
}elseif($hospital_name == 'LUTH'){
    $full_name = 'Lagos University Teaching Hospital, Idi-Arabaa';
}elseif($hospital_name == 'LAUTECHTH'){
    $full_name = 'LAUTECH Teaching Hospital, Osogbo / Ogbomoso';
}elseif($hospital_name == 'MUTH'){
    $full_name = 'Madonna University Teaching Hospital';
}elseif($hospital_name == 'MHHE'){
    $full_name = 'Memphys Hospital for Neurosurgery, Enugu';
}elseif($hospital_name == 'MBHB'){
    $full_name = 'Military Base Hospital, Benin';
}elseif($hospital_name == 'MHI'){
    $full_name = 'Motayo Hospital, Ikeja';
}elseif($hospital_name == 'NAFHI'){
    $full_name = 'NAF Hospital, Ikeja';
}elseif($hospital_name == 'NAFHI'){
    $full_name = 'NAF Hospital, Ikeja';
}elseif($hospital_name == 'NAFHI'){
    $full_name = 'NAF Hospital, Ikeja';
}elseif($hospital_name == 'NAHA'){
    $full_name = 'National Hospital Abuja';
}elseif($hospital_name == 'NHO'){
    $full_name = 'Naval Hospital, Ojo 16';
}elseif($hospital_name == 'NAFHI'){
    $full_name = 'NAF Hospital, Ikeja';
}elseif($hospital_name == 'NDUTH'){
    $full_name = 'Niger Delta University Teaching Hospital, Okolobiri 36';
}elseif($hospital_name == 'NAUTH'){
    $full_name = 'Nnamdi Azikiwe University Teaching Hosp. Nnewi';
}elseif($hospital_name == 'OAUTHC'){
    $full_name = 'OAU Teaching Hospital Complex, Ile-Ife';
}elseif($hospital_name == 'OOUTH'){
    $full_name = 'Olabisi Onabanjo (Ogun State) University Teaching Hospital, Sagamu 40';
}elseif($hospital_name == 'OMCU'){
    $full_name = 'Oriafor Medical Centre Uromi, Edo state';
}elseif($hospital_name == 'PGH'){
    $full_name = 'Parklane General Hospital, Enugu';
}elseif($hospital_name == 'PGJ'){
    $full_name = 'Plateau Hospital Jos';
}elseif($hospital_name == 'RRSHC'){
    $full_name = 'Ring Road Specialist Hospital Complex, Ibadan';
}elseif($hospital_name == 'SAH'){
    $full_name = 'Seventh-day Adventist Hospital, Ile-Ife';
}elseif($hospital_name == 'SSHI'){
    $full_name = 'Sobi Specialist Hospital, Ilorin';
}elseif($hospital_name == 'LHA'){
    $full_name = 'Luke Hospital Anua';
}elseif($hospital_name == 'NHL'){
    $full_name = 'Nicholas Hospital, Lagos';
}elseif($hospital_name == 'SHA'){
    $full_name = 'State Hospital Asubiaro, Osogbo';
}elseif($hospital_name == 'SHAAB'){
    $full_name = 'State Hospital, Abeokuta';
}elseif($hospital_name == 'SHAK'){
    $full_name = 'State Hospital, Akure ';
}elseif($hospital_name == 'SHMCA'){
    $full_name = 'State House Medical Centre Abuja';
}elseif($hospital_name == 'SSHI'){
    $full_name = 'State specialist hospital Ikere-Ekiti';
}elseif($hospital_name == 'UCHI'){
    $full_name = 'University College Hospital, Ibadan';
}elseif($hospital_name == 'UATH'){
    $full_name = 'University of Abuja Teaching Hospital Gwagwalada';
}elseif($hospital_name == 'UBTH'){
    $full_name = 'University of Benin Teaching Hospital, Benin City';
}elseif($hospital_name == 'UCTH'){
    $full_name = 'University of Calabar Teaching Hospital';
}elseif($hospital_name == 'UITH'){
    $full_name = 'University of Ilorin Teaching Hospital, Ilorin';
}elseif($hospital_name == 'UMTH'){
    $full_name = 'University of Maiduguri Teaching Hospital';
}elseif($hospital_name == 'UNTH'){
    $full_name = 'University of Nigeria Teaching Hospital, Enugu';
}elseif($hospital_name == 'UPHTH'){
    $full_name = 'University of Port Harcourt Teaching Hospital';
}elseif($hospital_name == 'UUTH'){
    $full_name = 'University of Uyo Teaching Hospital';
}elseif($hospital_name == 'UTHA'){
    $full_name = 'University Teaching Hospital Ado-Ekiti';
}elseif($hospital_name == 'UDUTH'){
    $full_name = 'Usmanu Danfodio University Teaching Hospital, Sokoto';
}elseif($hospital_name == 'FDH'){
    $full_name = 'FCT District Hospitals';
}elseif($hospital_name == 'FMCA'){
    $full_name = 'Federal Medical Centre Abeokuta';
}elseif($hospital_name == 'FMCAB'){
    $full_name = 'Federal Medical Centre, Abuja';
}elseif($hospital_name == 'FMCAE'){
    $full_name = 'Federal Medical Centre, Abakaliki, Ebonyi State';
}elseif($hospital_name == 'FMCAS'){
    $full_name = 'Federal Medical Centre Asaba';
}elseif($hospital_name == 'FMCB'){
    $full_name = 'Federal Medical Centre Bid';
}elseif($hospital_name == 'FMCEM'){
    $full_name = 'Federal Medical Centre Ebute-Metta';
}elseif($hospital_name == 'FMCK'){
    $full_name = 'Federal Medical Centre Keffi';
}elseif($hospital_name == 'FMCL'){
    $full_name = 'Federal Medical Centre Lokoja';
}elseif($hospital_name == 'FMCM'){
    $full_name = 'Federal Medical Centre Makurdi';
}elseif($hospital_name == 'FMCO'){
    $full_name = 'Federal Medical Centre Owerri';
}elseif($hospital_name == 'FMCOW'){
    $full_name = 'Federal Medical Centre Owo';
}elseif($hospital_name == 'FMCY'){
    $full_name = 'Federal Medical Centre Yenagoa';
}elseif($hospital_name == 'FMCU'){
    $full_name = 'Federal Medical Centre Umuahia';
}elseif($hospital_name == 'FTHA'){
    $full_name = 'Federal Teaching Hospital Abakaliki';
}elseif($hospital_name == 'FTHI'){
    $full_name = 'Federal Teaching Hospital Ido-Ekiti';
}elseif($hospital_name == 'FTHG'){
    $full_name = 'Federal Teaching Hospital, Gombe';
}elseif($hospital_name == 'FMCAY'){
    $full_name = 'Federal Medical Centre,  Yola';
}elseif($hospital_name == 'FMCK'){
    $full_name = 'Federal Medical Centre,  Katsina';
}elseif($hospital_name == 'FMCAB'){
    $full_name = 'Federal Medical Centre, Azare,  Bauchi';
}elseif($hospital_name == 'FMCBK'){
    $full_name = 'Federal Medical Centre,  Birnin-Kebbi, Kebbi';
}elseif($hospital_name == 'FMCBJ'){
    $full_name = 'Federal Medical Centre,  Birnin-Kudu, Jigawa';
}elseif($hospital_name == 'FMCNY'){
    $full_name = 'Federal Medical Centre, Nguru, Yobe';
}elseif($hospital_name == 'FMCGZ'){
    $full_name = 'Federal Medical Centre, Gusau, Zamfara State ';
}elseif($hospital_name == 'FMCJT'){
    $full_name = 'Federal Medical Centre, Jalingo, Taraba State ';
}elseif($hospital_name == 'FMCGZS'){
    $full_name = 'Federal Medical Centre, Gusau, Zamfara State ';
}






?>