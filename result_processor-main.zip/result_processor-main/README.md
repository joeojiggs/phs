# result_processor
 Result processing system for primary and secondary schools
